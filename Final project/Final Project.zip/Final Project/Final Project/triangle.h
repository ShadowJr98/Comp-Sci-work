#include <iomanip>

using namespace std;

class TriangleClass
{
private:
	int Base;

public:
	void setBase(int);

	void makeTriangle() const;
};